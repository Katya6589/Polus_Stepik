#  widget - это имя, присваиваемое компоненту пользовательского интерфейса,
#  с которым пользователь может взаимодействовать 
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (    
    QDialog, QTableWidgetItem # это базовый класс диалогового окна
)

from PyQt5.uic import loadUi # загрузка интерфейса, созданного в Qt Creator

import sqlite3

class Master(QDialog):
    def __init__(self, table, typeMaster):        
        super(Master, self).__init__()
        print("sgaclusa")
        self.tableWidget_master = table
        print(table)
        self.vivod(typeMaster)

    def  vivod(self,typeMaster):
        conn = sqlite3.connect("Autorizaciya/uchet.db") #подключение к бд
        cur = conn.cursor() #создаем переменную для хранения запросов
        zayavki = cur.execute(f'''SELECT 
            r.IDrequest as "Номер заявки",
            r.startDate as "Дата начала",
            ott.orgTechType as "Тип организации",
            r.orgTechModel as "Модель",
            r.problemDescryption as "Проблема",
            rs.requestStatus as "Статус заявки",
            r.completionDate as "Дата окончания",
            r.repairParts as "Детали для ремонта",
            us.fio as "ФИО мастера",
            user.fio as "ФИО клиента",
			com.message as "Коментарии"
            from requests r
            left join 
            orgTechTypes ott on r.orgTechTypeID = ott.IDorgTechType
            left JOIN
            requestStatuses rs on r.requestStatusID = rs.IDrequestStatus
            left join 
            users us on r.masterID = us.IDuser
            left join 
            users user on r.clientID = user.IDuser
			left join 
			comments com on r.IDrequest = com.requestID
            where r.masterID = "{typeMaster[0]}"
            ''') #получаем тип пользователя, логин и пароль которого был введен
        print(zayavki)
            
        name_stolba = [xz[0] for xz in zayavki.description] #вывод названия столбцов
        print(name_stolba)

        self.tableWidget_master.setColumnCount(len(name_stolba)) #считает количество столбцов
        self.tableWidget_master.setHorizontalHeaderLabels(name_stolba) #вместо цифр подставляет названия столбцов 

        dan_table= cur.fetchall()#получает все даные из базы, но они не структурированы

        self.tableWidget_master.setRowCount(0) #убирает появление пустых строк
        # row - строки
        for i, row in enumerate(dan_table): #цикл по строкам
            self.tableWidget_master.setRowCount(self.tableWidget_master.rowCount() + 1) #добавил пустые строки в нужном количестве
            for l, cow in enumerate(row): #начинает по ячейке заносить данные
                self.tableWidget_master.setItem(i,l,QTableWidgetItem(str(cow)))
        print(dan_table)

        self.tableWidget_master.resizeColumnsToContents() #столбцы стали по размеру данных

        conn.commit() #сохраняет в подключении запросы
        conn.close() #закрывает подключение