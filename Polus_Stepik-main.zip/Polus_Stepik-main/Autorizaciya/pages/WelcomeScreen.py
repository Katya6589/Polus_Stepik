#  widget - это имя, присваиваемое компоненту пользовательского интерфейса,
#  с которым пользователь может взаимодействовать 
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (    
    QDialog,
     QTableWidget # это базовый класс диалогового окна
)

from PyQt5.uic import loadUi # загрузка интерфейса, созданного в Qt Creator

import sqlite3

from pages.Zakazchik import Zakazchik
from pages.Master import Master
from pages.Operator import Operator
from pages.Manager import Manager
from pages.AddRequests import AddRequests

# Окно приветствия
class WelcomeScreen(QDialog):
    """
    Это класс окна приветствия.
    """
    def __init__(self):
        """
        Это конструктор класса
        """
        super(WelcomeScreen, self).__init__()
        loadUi("Autorizaciya/views/welcomescreen.ui",self) # загружаем интерфейс.
        self.PasswordField.setEchoMode(QtWidgets.QLineEdit.Password) # скрываем пароль
        self.SignInButton.clicked.connect(self.signupfunction) # нажати на кнопку и вызов функции
        self.back.clicked.connect(self.backs)
        self.back.hide()
        self.add_button.clicked.connect(self.add)
        self.add_button.hide()

        self.Save.clicked.connect(self.save_func)
        self.Save.hide()

        self.stackedWidget.currentChanged.connect(self.hiddenButton)

    def save_func(self):
        print("opoke")
        IDrequest = self.IDrequest_lE.text()
        print(IDrequest)
        startDate = self.startDate_LE.text()
        print(startDate)
        orgTechTypeID = self.orgTechTypeID_LE.text()
        print(orgTechTypeID)
        orgTechModel = self.orgTechModel_LE.text()
        print(orgTechModel)
        problemDescryption = self.problemDescryption_LE.text()
        print(problemDescryption)
        requestStatusID = self.requestStatusID_LE.text()
        print(requestStatusID)
        completionDate = self.completionDate_LE.text()
        print(completionDate)
        repairParts = self.repairParts_LE.text()
        print(repairParts)
        masterID = self.masterID_LE.text()
        print(masterID)
        clientID = self.clientID_LE.text()
        print(clientID)

        

        conn = sqlite3.connect("Autorizaciya/uchet.db") #подключение к бд
        cur = conn.cursor() #создаем переменную для хранения запросов
       
        #cur.execute(f'''INSERT INTO requests (IDrequest, startDate, orgTechTypeID, orgTechModel, problemDescryption, requestStatusID, completionDate, repairParts, masterID, clientID) VALUES (7, "2023-08-10", 1, "pypypy", "Перестал работать", 2,"2023-05-23","2023-05-23", 2, 7) ''') #получаем тип пользователя, логин и пароль которого был введен
        conn.commit() #сохраняет в подключении запросы
        conn.close() #закрывает подключение
        
        
        # Подключение кнопок к методам переключения страниц с использованием lambda
        #self.SignInButton.clicked.connect(lambda: self.stackedWidget.setCurrentWidget(self.Zakazchik))

    def signupfunction(self): # создаем функцию регистрации

        
        user = self.LoginField.text() # создаем пользователя и получаем из поля ввода логина введенный текст
        password = self.PasswordField.text() # создаем пароль и получаем из поля ввода пароля введенный текст
        print(user, password) # выводит логин и пароль

        if len(user)==0 or len(password)==0: # если пользователь оставил пустые поля
            self.ErrorField.setText("Заполните все поля") # выводим ошибку в поле
        else:
            self.ErrorField.setText(" ") # выводим что все хорошо в поле

            conn = sqlite3.connect("Autorizaciya/uchet.db") # подключение к базе данных в () изменить на название своей БД
            cur = conn.cursor() # переменная для запросов

            cur.execute('SELECT typeID FROM users WHERE login=(?) and password=(?)', [user, password]) # получаем тип пользователя, логин и пароль которого был введен
            typeUser = cur.fetchone() # получает только один тип пользователя
            #print(typeUser[0]) # выводит тип пользователя без скобок      
            if typeUser == None:
                self.ErrorField.setText("Пользователь с такими данными не найден")
            elif typeUser[0] == 4:
                cur.execute('SELECT IDuser FROM users WHERE login=(?) and password=(?)', [user, password]) # получаем id пользователя для получения фио, через логин и пароль которого был введен
                typeZakazchik = cur.fetchone() # получает только один тип пользователя

                self.tableWidget_zakazchik = self.findChild(QTableWidget, "tableWidget_zakazchik") #находит в приложении нужную таблицу
                self.stackedWidget.setCurrentWidget(self.Zakazchik)
                self.lybaya = Zakazchik(self.tableWidget_zakazchik, typeZakazchik)
           
            elif typeUser[0] == 2:
                cur.execute('SELECT IDuser FROM users WHERE login=(?) and password=(?)', [user, password]) # получаем id пользователя для получения фио, через логин и пароль которого был введен
                typeMaster = cur.fetchone() # получает только один тип пользователя

                self.tableWidget_master = self.findChild(QTableWidget, "tableWidget_master") #находит в приложении нужную таблицу
                self.stackedWidget.setCurrentWidget(self.Master)
                self.lybaya = Master(self.tableWidget_master, typeMaster)
            elif typeUser[0] == 3:
                self.tableWidget_operator = self.findChild(QTableWidget, "tableWidget_operator") #находит в приложении нужную таблицу
                self.stackedWidget.setCurrentWidget(self.Operator)
                self.lybaya = Operator(self.tableWidget_operator)
            elif typeUser[0] == 1:
                self.tableWidget_manager = self.findChild(QTableWidget, "tableWidget_manager") #находит в приложении нужную таблицу
                self.stackedWidget.setCurrentWidget(self.Manager)
                self.lybaya = Manager(self.tableWidget_manager)


            conn.commit() # сохраняет в подключении запросы
            conn.close() # закрываем подключение

    def backs(self):
        self.stackedWidget.setCurrentWidget(self.Avtorisation)
        self.lybaya = WelcomeScreen()
        print("oke")

    def add(self):
        self.stackedWidget.setCurrentWidget(self.Add_requests)
        self.lybaya = AddRequests()
        print("oke")
        
        

    def hiddenButton(self):
        if self.stackedWidget.currentWidget() == self.Avtorisation:   
            self.back.hide() #скрыть кнопку назад
            self.add_button.hide() #скрыть кнопку добавить
        else:
            self.back.show()
            self.add_button.show()

        if self.stackedWidget.currentWidget() != self.Add_requests:   
            self.Save.hide() 
        else:
            self.Save.show()


