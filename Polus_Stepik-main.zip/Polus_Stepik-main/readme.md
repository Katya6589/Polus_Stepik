1 Менеджер login1 pass1 
2 Мастер login2  pass2 
3 Оператор login4 pass4 
4 Заказчик login11 pass11

Добавление строки в таблицу
INSERT INTO requests (IDrequest, startDate, orgTechTypeID, orgTechModel, problemDescryption, requestStatusID, completionDate, repairParts, masterID, clientID) VALUES (6, "2023-08-10", 1, "pypypy", "Перестал работать", 2," "," ", 2, 7) 