from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QDialog
)
from PyQt5.uic import loadUi
import sqlite3

class NeAvtorizovan (QDialog):
    def __init__(self):
        super(NeAvtorizovan, self).__init__()