from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QDialog, QTableWidget
)
from PyQt5.uic import loadUi
import sqlite3

from pages.Klient import Klient #менять
from pages.Manager import Manager #менять
from pages.Administator import Administator #менять
from pages.NeAvtorizovan import NeAvtorizovan #менять
from pages.AddStroki import AddStroki #менять

class WelcomeScreen(QDialog):
    def __init__(self):
        super(WelcomeScreen, self).__init__()
        loadUi ("views/welcomeScreen.ui", self) # views/welcomeScreen.ui менять
        self.Password_q.setEchoMode(QtWidgets.QLineEdit.Password)  # Password_q из юи ввод пароля менять
        self.Vxod_q.clicked.connect(self.registaciya) # Vxod_q из юи вход кнопка менять registaciya функция внизу менять
        self.NoAkkaynt_q.clicked.connect(self.NeAvtorizovan) # NoAkkaynt_q из юи нет аккаунта кнопка менять NeAvtorizovan функция внизу менять
        
        self.back_q.clicked.connect(self.back)# back_q из юи нет назад кнопка менять back функция внизу менять
        self.back_q.hide()# back_q из юи нет назад кнопка менять
        self.Add_q.clicked.connect(self.add)# Add_q из юи добавить  кнопка менять add функция внизу менять
        self.Add_q.hide()# Add_q из юи добавить  кнопка менять

        self.save_q.hide()# save_q из юи сохранть назад кнопка менять
        self.save_q.clicked.connect(self.save_func) #save_q из юи сохранть назад кнопка менять и save_func функция внизу менять

        self.stackedWidget.currentChanged.connect(self.hiddenButton) #hiddenButton функция внизу менять

    def save_func(self):
        ID = self.ID.text() #1 id ваше любое название 2-ое из юи где ввод менять (с остальными также)
        print(ID)
        Date_zakaza = self.Date_zakaza.text()
        print(Date_zakaza)
        id_Sostav_tovara = self.id_Sostav_tovara.text()
        print(id_Sostav_tovara)
        Sum = self.Sum.text()
        print(Sum)
        Sum_Sale = self.Sum_Sale.text()
        print(Sum_Sale)
        Itog_price = self.Itog_price.text()
        print(Itog_price)
        Code_polycheniya = self.Code_polycheniya.text()
        print(Code_polycheniya)
        id_Pynkt_vidachi = self.id_Pynkt_vidachi.text()
        print(id_Pynkt_vidachi)
        Id_Terminal = self.Id_Terminal.text()
        print(Id_Terminal)
        id_Klient = self.id_Klient.text()
        print(id_Klient)
       

        conn = sqlite3.connect("Knizni_club.db") #Knizni_club.db менять
        cur = conn.cursor() #создаем переменную для хранения запросов
       
        #Talon МЕНЯТЬ и названия столбцов менять  и то что после VALUES заменить на то, что написано выше
        cur.execute(f'''INSERT INTO Talon (ID, Date_zakaza, id_Sostav_tovara, Sum, Sum_Sale, Itog_price, Code_polycheniya, id_Pynkt_vidachi, Id_Terminal, id_Klient) VALUES ({ID}, "{Date_zakaza}", {id_Sostav_tovara}, "{Sum}", "{Sum_Sale}", "{Itog_price}",{Code_polycheniya},"{id_Pynkt_vidachi}", {Id_Terminal}, {id_Klient}) ''') #получаем тип пользователя, логин и пароль которого был введен
        conn.commit() #сохраняет в подключении запросы
        conn.close() #закрывает подключение



    def registaciya(self):
        login = self.Login_q.text() #Login_q ввод логина из юи менять
        password = self.Password_q.text() #Password_q ввод пароля из юи менять
       
        if len(login) == 0 or len(password) == 0: #Password_q Login_q менять
            self.Error_q.setText("Поля должны быть заполнены") #Error_q строка вывода ошибок менять
        else:
            self.Error_q.setText(" ")#Error_q строка вывода ошибок менять
            conn = sqlite3.connect("Knizni_club.db")#базу менять
            cur = conn.cursor()

            cur.execute(f'SELECT Type_atorizovan_id FROM Klient where Login = "{login}" and Password = "{password}"') #Type_atorizovan_id и Klient менять (Login и Password должны быть в таблице)
            typeUser = cur.fetchone() 
            if typeUser == None:
                self.Error_q.setText("Такого пользователя нет") #Error_q строка вывода ошибок менять
            elif typeUser[0] == 1:
                cur.execute(f'SELECT id FROM Klient WHERE Login = "{login}" and Password = "{password}"') #id и Klient менять (Login и Password должны быть в таблице)
                typeUs = cur.fetchone()

                self.tableWidget_Klient = self.findChild(QTableWidget, "tableWidget_Klient") #tableWidget_Klient МЕНЯТЬ
                self.stackedWidget.setCurrentWidget(self.Klient_q) #Klient_q страница из юи менять
                self.lybaya = Klient(self.tableWidget_Klient, typeUs) #Klient это класс из файла который мы создали менять, tableWidget_Klient менять это то где будет выводиться база
                #с остальными пж по примеру 
            elif typeUser[0] == 3:
                self.stackedWidget.setCurrentWidget(self.Manager_q)
                self.lybaya = Manager()
            elif typeUser[0] == 4:
                self.stackedWidget.setCurrentWidget(self.Administator_q)
                self.lybaya = Administator()


            conn.commit()
            conn.close()
        
    def NeAvtorizovan(self):
        self.stackedWidget.setCurrentWidget(self.NeAvtorizovan_q) #NeAvtorizovan_q СТРАНМца из юи менчть (это возможно не будет, это отдельная кпонка кто не авторизован и может просматрировать товары, если таких условий не буде удалите функцию и допишите сверху переходы по страницам, ПОДКЛЮЧЕНИЕ К  КНОПКЕ СВЕРХУ ТОЖЕ ТОГДА УДАЛИТЬ )
        self.lybaya = NeAvtorizovan() #NeAvtorizovan КЛАСС который мы сохали менять
    
    def back(self):
        self.stackedWidget.setCurrentWidget(self.Avtorizaciya_q)#Avtorizaciya_q СТРАНица из юи авторизации менчть
        self.lybaya = WelcomeScreen() #WelcomeScreen класс в которым вы щас пишите 
    
    def add(self):
        self.stackedWidget.setCurrentWidget(self.AddStoki_q)#AddStoki_q СТРАНица из юи добавление строк менчть
        self.lybaya = AddStroki() #AddStroki класс добавления строк менять
    
    def hiddenButton(self):
        if self.stackedWidget.currentWidget() == self.Avtorizaciya_q:#Avtorizaciya_q СТРАНица из юи авторизации менчть
            self.back_q.hide()# back_q из юи назад  кнопка менять
            self.Add_q.hide()# Add_q из юи добавить  кнопка менять
        else:
            self.back_q.show()# back_q из юи назад  кнопка менять
            self.Add_q.show()# Add_q из юи добавить  кнопка менять
        if self.stackedWidget.currentWidget() != self.AddStoki_q:#AddStoki_q СТРАНица из юи добавление строк менчть
            self.save_q.hide()# save_q из юи сохранить  кнопка менять
        else:
            self.save_q.show()# save_q из юи сохранить  кнопка менять

