from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QDialog
)
from PyQt5.uic import loadUi
import sqlite3


class Klient (QDialog):
    def __init__(self):
        super(Klient, self).__init__()

        
    
   