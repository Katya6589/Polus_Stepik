from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QDialog, 
)
from PyQt5.uic import loadUi
import sqlite3

from pages.Klient import Klient
from pages.Manager import Manager
from pages.Administator import Administator
from pages.NeAvtorizovan import NeAvtorizovan

class WelcomeScreen(QDialog):
    def __init__(self):
        super(WelcomeScreen, self).__init__()
        loadUi ("views/welcomeScreen.ui", self)
        self.Password_q.setEchoMode(QtWidgets.QLineEdit.Password)
        self.Vxod_q.clicked.connect(self.registaciya)
        self.NoAkkaynt_q.clicked.connect(self.NeAvtorizovan)
        
        self.back_q.clicked.connect(self.back)
        self.back_q.hide()

        self.stackedWidget.currentChanged.connect(self.hiddenButton)


    def registaciya(self):
        login = self.Login_q.text()
        password = self.Password_q.text()
        print(login, password)
        if len(login) == 0 or len(password) == 0:
            self.Error_q.setText("Поля должны быть заполнены")
        else:
            self.Error_q.setText(" ")
            conn = sqlite3.connect("Knizni_club.db")
            cur = conn.cursor()

            cur.execute(f'SELECT Type_atorizovan_id FROM Klient where Login = "{login}" and Password = "{password}"')
            typeUser = cur.fetchone()
            if typeUser == None:
                self.Error_q.setText("Такого пользователя нет")
            elif typeUser[0] == 1:
                self.stackedWidget.setCurrentWidget(self.Klient_q)
                self.lybaya = Klient()
            elif typeUser[0] == 3:
                self.stackedWidget.setCurrentWidget(self.Manager_q)
                self.lybaya = Manager()
            elif typeUser[0] == 4:
                self.stackedWidget.setCurrentWidget(self.Administator_q)
                self.lybaya = Administator()


            conn.commit()
            conn.close()
        
    def NeAvtorizovan(self):
        self.stackedWidget.setCurrentWidget(self.NeAvtorizovan_q)
        self.lybaya = NeAvtorizovan()
    
    def back(self):
        self.stackedWidget.setCurrentWidget(self.Avtorizaciya_q)
        self.lybaya = WelcomeScreen()
    
    def hiddenButton(self):
        if self.stackedWidget.currentWidget() == self.Avtorizaciya_q:
            self.back_q.hide()
        else:
            self.back_q.show()
